/**
 * editor.js — Editor interactivity
 * Line numbers, tab handling, syntax highlighting, cursor position
 */

const codeInput    = document.getElementById('codeInput');
const lineNumbers  = document.getElementById('lineNumbers');
const cursorPos    = document.getElementById('cursorPos');
const fileLabel    = document.getElementById('fileLabel');
const langLabel    = document.getElementById('langLabel');
const navTabs      = document.querySelectorAll('.nav-tab');

let currentLang = 'c';

// Default snippets per language
const SNIPPETS = {
  c: `#include <stdio.h>

int main() {
    int x = 10;
    int y = 20;
    int sum = x + y;
    printf("Sum = %d\\n", sum);
    printf("Hello, World!\\n");
    return 0;
}`,
  cpp: `#include <iostream>
using namespace std;

int main() {
    int x = 10;
    int y = 20;
    int sum = x + y;
    cout << "Sum = " << sum << endl;
    cout << "Hello from C++!" << endl;
    return 0;
}`,
  java: `public class Main {
    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        int sum = x + y;
        System.out.println("Sum = " + sum);
        System.out.println("Hello from Java!");
    }
}`,
  python: `# Python program
def add(a, b):
    return a + b

x = 10
y = 20
result = add(x, y)
print("Sum =", result)
print("Hello from Python!")
`
};

const FILE_NAMES = { c: 'main.c', cpp: 'main.cpp', java: 'Main.java', python: 'main.py' };

// ===== INIT =====
function initEditor() {
  codeInput.value = SNIPPETS[currentLang];
  updateLineNumbers();
  updateFileLabel();
}

// ===== LINE NUMBERS =====
function updateLineNumbers() {
  const lines = codeInput.value.split('\n');
  lineNumbers.innerHTML = lines.map((_, i) =>
    `<span>${i + 1}</span>`
  ).join('');
  syncScroll();
}

function syncScroll() {
  lineNumbers.scrollTop = codeInput.scrollTop;
}

codeInput.addEventListener('input', updateLineNumbers);
codeInput.addEventListener('scroll', syncScroll);
codeInput.addEventListener('keydown', handleTabKey);

// ===== TAB KEY =====
function handleTabKey(e) {
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = codeInput.selectionStart;
    const end   = codeInput.selectionEnd;
    codeInput.value = codeInput.value.substring(0, start) + '  ' + codeInput.value.substring(end);
    codeInput.selectionStart = codeInput.selectionEnd = start + 2;
    updateLineNumbers();
  }
}

// ===== CURSOR POSITION =====
codeInput.addEventListener('keyup', updateCursor);
codeInput.addEventListener('click', updateCursor);
codeInput.addEventListener('selectionchange', updateCursor);

function updateCursor() {
  const text = codeInput.value.substring(0, codeInput.selectionStart);
  const lines = text.split('\n');
  const line = lines.length;
  const col  = lines[lines.length - 1].length + 1;
  cursorPos.textContent = `Line ${line}, Col ${col}`;
}

// ===== LANGUAGE TABS =====
navTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    navTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentLang = tab.dataset.lang;
    codeInput.value = SNIPPETS[currentLang];
    updateLineNumbers();
    updateFileLabel();
    resetPhases();
    clearOutput();
  });
});

function updateFileLabel() {
  fileLabel.textContent = FILE_NAMES[currentLang] || 'main.c';
  langLabel.textContent = currentLang.toUpperCase();
}

// ===== FORMAT BUTTON =====
document.getElementById('formatBtn').addEventListener('click', () => {
  // Simple indentation formatter
  const lines = codeInput.value.split('\n');
  let indent = 0;
  const formatted = lines.map(line => {
    const trimmed = line.trim();
    if (trimmed.endsWith('}') || trimmed === '}') indent = Math.max(0, indent - 1);
    const result = '  '.repeat(indent) + trimmed;
    if (trimmed.endsWith('{')) indent++;
    return result;
  });
  codeInput.value = formatted.join('\n');
  updateLineNumbers();
});

// ===== COPY BUTTON =====
document.getElementById('copyBtn').addEventListener('click', () => {
  navigator.clipboard.writeText(codeInput.value).then(() => {
    const toast = document.createElement('div');
    toast.className = 'copy-toast';
    toast.textContent = 'Copied!';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 1500);
  });
});

// ===== CLEAR BUTTON =====
document.getElementById('clearBtn').addEventListener('click', () => {
  codeInput.value = '';
  updateLineNumbers();
  clearOutput();
  resetPhases();
  document.getElementById('tokensList').innerHTML = '<span class="placeholder-text">Run code to see tokens...</span>';
  document.getElementById('tokenCount').textContent = '0 tokens';
});

function clearOutput() {
  document.getElementById('outputBody').innerHTML = '<span class="placeholder-text">Output will appear here after running your code...</span>';
  document.getElementById('execTime').textContent = '0ms';
}

// Expose for runner.js
function getCurrentLang() { return currentLang; }
function getCode() { return codeInput.value; }

initEditor();
