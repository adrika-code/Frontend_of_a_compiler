/**
 * themes.js — Theme switching
 */

const themeSelect = document.getElementById('themeSelect');

themeSelect.addEventListener('change', () => {
  document.body.className = '';
  const val = themeSelect.value;
  if (val === 'light') document.body.classList.add('theme-light');
  if (val === 'monokai') document.body.classList.add('theme-monokai');
});
