/**
 * runner.js — Orchestrates compilation phases with animations
 */

const runBtn     = document.getElementById('runBtn');
const statusMsg  = document.getElementById('statusMsg');
const outputBody = document.getElementById('outputBody');
const execTime   = document.getElementById('execTime');
const tokensList = document.getElementById('tokensList');
const tokenCount = document.getElementById('tokenCount');

const PHASES = ['lexer', 'parser', 'semantic', 'codegen'];

// ===== RESET PHASES =====
function resetPhases() {
  PHASES.forEach(p => {
    const phase  = document.getElementById(`phase-${p}`);
    const status = document.getElementById(`status-${p}`);
    if (phase)  phase.classList.remove('active', 'done', 'error');
    if (status) status.className = 'phase-status idle';
  });
}

// ===== ANIMATE A SINGLE PHASE =====
function animatePhase(name, delayMs) {
  return new Promise(resolve => {
    setTimeout(() => {
      const phase  = document.getElementById(`phase-${name}`);
      const status = document.getElementById(`status-${name}`);
      if (phase)  phase.classList.add('active');
      if (status) status.className = 'phase-status active';
      statusMsg.textContent = `Running ${name.charAt(0).toUpperCase() + name.slice(1)}...`;
    }, delayMs);

    setTimeout(() => {
      const phase  = document.getElementById(`phase-${name}`);
      const status = document.getElementById(`status-${name}`);
      if (phase) { phase.classList.remove('active'); phase.classList.add('done'); }
      if (status) status.className = 'phase-status done';
      resolve();
    }, delayMs + 550);
  });
}

// ===== MARK PHASE AS ERROR =====
function markPhaseError(name) {
  const phase  = document.getElementById(`phase-${name}`);
  const status = document.getElementById(`status-${name}`);
  if (phase) { phase.classList.remove('active', 'done'); phase.classList.add('error'); }
  if (status) status.className = 'phase-status error';
}

// ===== RENDER TOKENS =====
function renderTokens(tokens) {
  tokensList.innerHTML = '';
  if (!tokens.length) {
    tokensList.innerHTML = '<span class="placeholder-text">No tokens found</span>';
    return;
  }
  tokens.slice(0, 80).forEach(tok => {
    const span = document.createElement('span');
    span.className = `token token-${tok.type}`;
    span.textContent = tok.value;
    span.title = `Type: ${tok.type} | Line: ${tok.line}`;
    tokensList.appendChild(span);
  });
  if (tokens.length > 80) {
    const more = document.createElement('span');
    more.className = 'placeholder-text';
    more.style.fontSize = '11px';
    more.textContent = ` +${tokens.length - 80} more tokens`;
    tokensList.appendChild(more);
  }
  tokenCount.textContent = `${tokens.length} tokens`;
}

// ===== RENDER OUTPUT =====
function renderOutput(result) {
  outputBody.innerHTML = '';

  if (result.parserErrors.length > 0) {
    result.parserErrors.forEach(err => {
      const line = document.createElement('span');
      line.className = 'output-line output-error';
      line.textContent = '✗ ' + err;
      outputBody.appendChild(line);
    });
  }

  if (result.semanticWarnings.length > 0) {
    result.semanticWarnings.forEach(w => {
      const line = document.createElement('span');
      line.className = 'output-line output-warn';
      line.textContent = '⚠ ' + w;
      outputBody.appendChild(line);
    });
  }

  if (result.parserErrors.length === 0) {
    const codeLine = document.createElement('span');
    codeLine.className = 'output-line output-info';
    codeLine.textContent = `✓ Compilation successful (${result.timeMs}ms)`;
    outputBody.appendChild(codeLine);

    const sep = document.createElement('span');
    sep.className = 'output-line';
    sep.textContent = '─'.repeat(40);
    sep.style.color = 'var(--border-light)';
    outputBody.appendChild(sep);
  }

  if (result.output) {
    result.output.split('\n').forEach((l, i) => {
      const line = document.createElement('span');
      line.className = 'output-line';
      line.style.animationDelay = `${i * 30}ms`;
      line.textContent = l;
      outputBody.appendChild(line);
    });
  }

  execTime.textContent = `${result.timeMs}ms`;
}

// ===== MAIN RUN HANDLER =====
runBtn.addEventListener('click', async () => {
  const code = getCode();
  const lang = getCurrentLang();

  if (!code.trim()) {
    statusMsg.textContent = 'No code to compile';
    return;
  }

  // Disable button during run
  runBtn.classList.add('running');
  runBtn.innerHTML = '<span class="compiling-spinner"></span> Running...';
  resetPhases();
  outputBody.innerHTML = '';
  tokensList.innerHTML = '';
  statusMsg.textContent = 'Starting compilation...';

  try {
    // Phase animations
    await animatePhase('lexer', 0);
    await animatePhase('parser', 100);
    await animatePhase('semantic', 200);
    await animatePhase('codegen', 300);

    // Actual compilation
    const result = compile(code, lang);

    // Render tokens
    renderTokens(result.tokens);

    // If errors, mark parser phase red
    if (result.parserErrors.length > 0) {
      markPhaseError('parser');
      markPhaseError('semantic');
      markPhaseError('codegen');
    }

    // Render output
    renderOutput(result);

    statusMsg.textContent = result.success
      ? `Compiled successfully — ${result.tokens.length} tokens, ${result.timeMs}ms`
      : `Compiled with ${result.parserErrors.length} error(s)`;

  } catch(e) {
    outputBody.innerHTML = `<span class="output-error">Fatal error: ${e.message}</span>`;
    statusMsg.textContent = 'Compilation failed';
    PHASES.forEach(p => markPhaseError(p));
  } finally {
    runBtn.classList.remove('running');
    runBtn.innerHTML = '<span>&#9654;</span> Run';
  }
});

// Also allow Ctrl+Enter to run
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    runBtn.click();
  }
});
