/**
 * lexer.js — Tokenizer for C/C++/Java/Python
 * Produces tokens with type, value, line number
 */

const KEYWORDS = {
  c: ['int','float','double','char','void','return','if','else','while','for','do','switch','case','break','continue','include','define','struct','typedef','enum','sizeof','const','static','extern','unsigned','signed','long','short','printf','scanf'],
  cpp: ['int','float','double','char','void','return','if','else','while','for','do','switch','case','break','continue','class','public','private','protected','new','delete','this','namespace','using','cout','cin','string','vector','bool','true','false','nullptr','const','static','template','typename','struct','enum','sizeof'],
  java: ['int','float','double','char','void','return','if','else','while','for','do','switch','case','break','continue','class','public','private','protected','new','this','static','final','interface','extends','implements','import','package','System','String','boolean','true','false','null','throws','try','catch','finally'],
  python: ['def','class','return','if','elif','else','while','for','in','import','from','as','pass','break','continue','try','except','finally','with','lambda','and','or','not','is','None','True','False','print','input','range','len','type','int','float','str','list','dict','tuple','set','self','global','nonlocal','yield','assert','del','raise']
};

const TOKEN_TYPES = {
  KEYWORD: 'keyword',
  IDENTIFIER: 'ident',
  NUMBER: 'number',
  STRING: 'string',
  OPERATOR: 'operator',
  PUNCTUATION: 'punc',
  COMMENT: 'comment',
  UNKNOWN: 'unknown'
};

/**
 * Main tokenize function
 * @param {string} code - source code
 * @param {string} lang - c | cpp | java | python
 * @returns {Array} array of token objects
 */
function tokenize(code, lang = 'c') {
  const tokens = [];
  const keywords = KEYWORDS[lang] || KEYWORDS.c;
  let i = 0;
  let line = 1;

  while (i < code.length) {
    const ch = code[i];

    // Newlines
    if (ch === '\n') {
      line++;
      i++;
      continue;
    }

    // Whitespace
    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // Single-line comment // or #
    if ((ch === '/' && code[i+1] === '/') || (ch === '#' && lang === 'python')) {
      let val = '';
      while (i < code.length && code[i] !== '\n') {
        val += code[i++];
      }
      tokens.push({ type: TOKEN_TYPES.COMMENT, value: val, line });
      continue;
    }

    // Multi-line comment /* */
    if (ch === '/' && code[i+1] === '*') {
      let val = '/*';
      i += 2;
      while (i < code.length && !(code[i] === '*' && code[i+1] === '/')) {
        if (code[i] === '\n') line++;
        val += code[i++];
      }
      val += '*/';
      i += 2;
      tokens.push({ type: TOKEN_TYPES.COMMENT, value: val, line });
      continue;
    }

    // String literals " or '
    if (ch === '"' || ch === "'") {
      const quote = ch;
      let val = ch;
      i++;
      while (i < code.length && code[i] !== quote) {
        if (code[i] === '\\') { val += code[i++]; }
        val += code[i++];
      }
      val += quote;
      i++;
      tokens.push({ type: TOKEN_TYPES.STRING, value: val, line });
      continue;
    }

    // Numbers (integers and floats)
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(code[i+1]))) {
      let val = '';
      while (i < code.length && /[0-9._xXa-fA-FbBoO]/.test(code[i])) {
        val += code[i++];
      }
      tokens.push({ type: TOKEN_TYPES.NUMBER, value: val, line });
      continue;
    }

    // Identifiers & keywords
    if (/[a-zA-Z_]/.test(ch)) {
      let val = '';
      while (i < code.length && /[a-zA-Z0-9_]/.test(code[i])) {
        val += code[i++];
      }
      const type = keywords.includes(val) ? TOKEN_TYPES.KEYWORD : TOKEN_TYPES.IDENTIFIER;
      tokens.push({ type, value: val, line });
      continue;
    }

    // Operators
    const twoChar = code.slice(i, i+2);
    if (['==','!=','<=','>=','&&','||','++','--','+=','-=','*=','/=','->','::','=>'].includes(twoChar)) {
      tokens.push({ type: TOKEN_TYPES.OPERATOR, value: twoChar, line });
      i += 2;
      continue;
    }
    if ('+-*/%=<>!&|^~'.includes(ch)) {
      tokens.push({ type: TOKEN_TYPES.OPERATOR, value: ch, line });
      i++;
      continue;
    }

    // Punctuation
    if ('{}[]();:.,?@'.includes(ch)) {
      tokens.push({ type: TOKEN_TYPES.PUNCTUATION, value: ch, line });
      i++;
      continue;
    }

    // Unknown char
    tokens.push({ type: TOKEN_TYPES.UNKNOWN, value: ch, line });
    i++;
  }

  return tokens;
}
