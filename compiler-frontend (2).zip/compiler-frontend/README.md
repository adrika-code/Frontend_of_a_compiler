# CompileX — Frontend of a Compiler

A fully functional **Compiler Frontend** built with HTML, CSS, and JavaScript.
Simulates all 4 phases of compilation with a VS Code-inspired dark interface.

---

## Project Structure

```
compiler-frontend/
├── index.html                  ← Main HTML file (open this in browser)
├── src/
│   ├── styles/
│   │   ├── main.css            ← Layout, themes, components
│   │   ├── editor.css          ← Code editor styles
│   │   └── output.css          ← Output panel, animations
│   ├── components/
│   │   ├── editor.js           ← Line numbers, tab handling, language switcher
│   │   ├── runner.js           ← Phase animation + compilation orchestration
│   │   └── themes.js           ← Dark / Light / Monokai theme switcher
│   └── utils/
│       ├── lexer.js            ← Tokenizer (Lexer phase)
│       └── compiler.js         ← Parser, Semantic Analyzer, Code Generator
└── README.md
```

---

## How to Run in VS Code

### Option 1: Live Server (Recommended)
1. Open VS Code
2. Install the **"Live Server"** extension (by Ritwick Dey)
3. Open `index.html`
4. Right-click → **"Open with Live Server"**
5. Browser opens automatically at `http://localhost:5500`

### Option 2: Direct Browser
1. Open `index.html` directly in any browser (double-click it)
2. Everything works without any server needed

---

## Features

| Feature | Description |
|---|---|
| **4 Compiler Phases** | Lexer → Parser → Semantic → Code Gen with animated status |
| **Token Visualization** | Color-coded tokens by type (keyword, identifier, number, string, operator) |
| **Syntax Error Detection** | Mismatched brackets, missing semicolons |
| **Semantic Warnings** | Unused variables, suspicious assignments in conditions |
| **Simulated Assembly Output** | x86-64 assembly stub based on your code |
| **4 Languages** | C, C++, Java, Python |
| **3 Themes** | Dark (Catppuccin), Light, Monokai |
| **Live Output Simulation** | Detects print/printf/cout/System.out.println |
| **Keyboard Shortcut** | Ctrl+Enter to run |
| **Code Formatter** | Auto-indent with { } button |

---

## Compiler Phases Explained

### Phase 1: Lexer (Tokenization)
- Scans source code character by character
- Produces tokens: KEYWORD, IDENTIFIER, NUMBER, STRING, OPERATOR, PUNCTUATION, COMMENT
- Handles comments, strings, multi-character operators (==, !=, ++)

### Phase 2: Parser (Syntax Analysis)
- Checks bracket matching: `{}`, `()`, `[]`
- Detects missing semicolons in C/C++/Java
- Reports line numbers in error messages

### Phase 3: Semantic Analysis
- Tracks variable declarations
- Warns about unused variables
- Detects possible `=` instead of `==` in conditions

### Phase 4: Code Generation
- Produces simulated x86-64 assembly
- Maps keywords to assembly constructs (loops, conditions, syscalls)

---

## Technologies Used
- **HTML5** — Structure
- **CSS3** — VS Code-inspired theming, animations, CSS variables
- **Vanilla JavaScript** — No frameworks, no dependencies
- **JetBrains Mono** — Code font (via Google Fonts)
